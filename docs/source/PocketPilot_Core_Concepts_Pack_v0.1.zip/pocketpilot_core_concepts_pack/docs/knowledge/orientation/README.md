# Orientation

Front-door product understanding, onboarding context, and the main operating surfaces.

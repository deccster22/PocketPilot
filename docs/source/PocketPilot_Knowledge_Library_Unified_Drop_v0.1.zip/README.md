# PocketPilot Knowledge Library Unified Drop v0.1

This package merges three previously separated artifacts into one repo-ready knowledge drop:
- knowledge scaffold
- core concepts pack
- 9-strategy launch pack

## Included
- `docs/knowledge/00-orientation/`
- `docs/knowledge/10-core-language/`
- `docs/knowledge/20-strategies/`
- `docs/knowledge/30-action-risk/`
- `docs/knowledge/40-reflection/`
- `docs/knowledge/50-knowledge-system/`
- `docs/knowledge/90-media/`
- `docs/knowledge/_register/`
- `docs/knowledge/_templates/`

## Notes
- Strategy docs are normalized draft nodes and should be treated as content-ready, pending any final founder wording pass.
- `what-log-and-journal-are-for.md` remains future-facing.
- Snapshot should remain a caution zone for contextual links even where related docs exist.

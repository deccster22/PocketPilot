# Knowledge System Shelf

This shelf explains how the Knowledge Library behaves inside PocketPilot.

Its job is to make the learning system legible as a product feature, not just as a content pile.

## Typical contents
- What the Knowledge Library Is For
- What Knowledge Links Are For
- Strategy Preview / Strategy Navigator explainers where appropriate

## Shelf rule
These docs should explain:
- why the knowledge layer exists
- why it stays optional
- how contextual links work
- how learning support differs by surface and profile

They should reinforce that PocketPilot knowledge is a handrail, not a gate.

## Best contextual homes
- top-level library
- onboarding
- product explanation surfaces
- internal IA / content planning reference

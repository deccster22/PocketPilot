# Strategies Shelf

This shelf is the strategy academy.

Strategy is the primary worldview lens inside PocketPilot, so this is not a side shelf. It is one of the core bodies of knowledge in the whole library.

## Typical contents
- launch strategy guides
- future strategy additions
- strategy exploration support such as Strategy Preview / Strategy Navigator

## Launch archetypes
### Value Hunter
- Buy the Dip
- Range Trader
- Reversion Bounce

### Trend Rider
- Trend Follow
- Breakout Watcher
- Momentum Pulse

### Pattern Navigator
- Candle Signals
- Fibonacci Zones
- Confluence Alignment

## Shelf rule
Strategy docs should explain:
- what the strategy is trying to do
- who it tends to suit
- the conditions it tends to like and dislike
- the main risks and common misunderstandings
- how the strategy appears inside PocketPilot

They should not drift into trade instruction, fake precision, or internal implementation fiction.

## Best contextual homes
- onboarding strategy selection
- Strategy Navigator / Preview
- Dashboard contextual links
- top-level strategy browsing

---
topicId: pp-what-trade-hub-is-for
title: "What Trade Hub Is For"
difficulty: Beginner
mediaType: article
reviewStatus: normalized-draft-v1
family: orientation
priority: Now
surfaceFit:
  - Lib
  - Trade
---
# What Trade Hub Is For

## Quick version
Trade Hub is PocketPilot’s action-support layer. It helps structure action when the user chooses to act, without turning the product into a casino panel.

## Full version
Trade Hub sits downstream from interpretation. If Snapshot is scan and Dashboard is focus, Trade Hub is the action layer.

Its purpose is to reduce friction **when the user has already chosen to act**, while preserving explicit control, confirmation, and a support-first posture.

## What it can include
- execution support
- risk tools
- SL/TP calculator
- ProtectionPlan framing
- confirmation-safe previews

## What it is not
- not auto-trading
- not hidden automation
- not one-tap gambling
- not a pressure surface

## Why it matters
It bridges interpretation and action cleanly. It helps the user move from understanding to preparation without collapsing the product’s calm tone.

## Key terms
- Trade Hub
- action layer
- confirmation
- support not enforcement

## Further reading
- Why PocketPilot Supports Action Without Pushing Action
- What Protection Plans Are For
- Stop Loss Basics

---
topicId: pp-what-snapshot-is-for
title: "What Snapshot Is For"
difficulty: Beginner
mediaType: article
reviewStatus: normalized-draft-v1
family: orientation
priority: Now
surfaceFit:
  - Lib
  - Snap
---
# What Snapshot Is For

## Quick version
Snapshot is PocketPilot’s zero-scroll re-entry screen. It is designed to help you understand where things stand for your strategy in a few seconds.

## Full version
Snapshot is the scan layer of the product. It is a calm briefing surface built around three core elements:
- Current State
- Last 24h Change
- Strategy Status

It exists to answer, quickly:
**What’s going on right now for my strategy?**

Snapshot is sacred in the product rules. It should not become a cluttered dashboard, a warning siren, or a study hall. Secondary chips are allowed only if they stay subordinate.

## What it is not
- not a giant indicator wall
- not a full analysis workspace
- not an urgency surface

## Why it matters
Snapshot gives users orientation first. It tells them whether they need to go deeper into Dashboard or simply close the app with confidence.

## Key terms
- Snapshot
- zero-scroll
- scan layer
- Strategy Status

## Further reading
- What Dashboard Is For
- What Since Last Checked Is For
- What Strategy Status Means

---
topicId: pp-what-pocketpilot-is
title: "What PocketPilot Is"
difficulty: Beginner
mediaType: article
reviewStatus: normalized-draft-v1
family: orientation
priority: Now
surfaceFit:
  - Lib
  - Onboard
---
# What PocketPilot Is

## Quick version
PocketPilot is a strategy-first crypto decision-support product. It is not a generic market app, not an auto-trading system, and not a machine for manufacturing urgency. Its job is to help users understand what market conditions mean for their chosen strategy, stay oriented when conditions shift, and act with more clarity when they choose to. 

## Full version
PocketPilot is best understood as a **strategy interpreter**. Most crypto products answer the question, “What is the market doing?” PocketPilot is built to answer a more useful question: **“What does the market mean for your strategy?”**

That difference matters. It means the product is designed around interpretation rather than information overload. Raw signals, indicators, and price movement are inputs. PocketPilot translates those inputs into strategy status, meaningful events, re-entry summaries, and action-support context.

The product follows a simple experience hierarchy:
- **Scan** through Snapshot
- **Focus** through Dashboard
- **Deep** through Insights and Knowledge

PocketPilot is also deliberately calm in tone. It should not use hype, casino-style mechanics, or fake certainty. It should not pressure the user into action. It is execution-aware, but user-directed.

A useful way to think about it is this: PocketPilot is trying to feel less like a noisy trading feed and more like a trusted instrument panel.

## What it is not
- not a prediction engine
- not auto-trading
- not a raw indicator wall
- not a hype machine

## Key terms
- strategy-first
- interpretation layer
- Scan / Focus / Deep
- calm over urgency

## Further reading
- Choosing Your Experience Level and Strategy
- What Snapshot Is For
- What Dashboard Is For
- What the Knowledge Library Is For

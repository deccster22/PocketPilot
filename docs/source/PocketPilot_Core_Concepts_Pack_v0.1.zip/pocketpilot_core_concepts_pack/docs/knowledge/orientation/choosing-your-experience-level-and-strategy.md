---
topicId: pp-choosing-profile-and-strategy
title: "Choosing Your Experience Level and Strategy"
difficulty: Beginner
mediaType: article
reviewStatus: normalized-draft-v1
family: orientation
priority: Now
surfaceFit:
  - Lib
  - Onboard
---
# Choosing Your Experience Level and Strategy

## Quick version
PocketPilot asks you to choose two things early: your experience level and your strategy. These are different choices. Your experience level shapes how the app explains things. Your strategy shapes what the app treats as meaningful.

## Full version
PocketPilot separates **profile**, **strategy**, and **voice** because they do different jobs.

**Profile** changes the relationship model:
- how much explanation you see
- how dense the interface feels
- how visible knowledge links are
- how much scaffolding you get

**Strategy** changes the interpretation layer:
- what signals matter most
- how the dashboard emphasizes conditions
- what alerts are relevant
- which educational links are useful

A beginner and an advanced user can choose the same strategy and still get the same underlying logic. What changes is the density, explanation depth, and support around that logic.

The launch strategy set has three archetypes with three strategies each:
- Value Hunter
- Trend Rider
- Pattern Navigator

Choosing a strategy is not a permanent identity test. Inside PocketPilot, changing strategy should feel like changing perspective inside the same cockpit, not moving to a different product. You can revisit your profile and strategy later.

## What matters most
- choose the profile that feels most natural right now
- choose the strategy lens that best matches how you want to read the market
- do not worry about getting trapped; the product is designed to let you adjust later

## Key terms
- profile
- strategy
- voice
- strategy-first

## Further reading
- What PocketPilot Is
- What Strategy Alignment Means
- What Strategy Preview / Strategy Navigator Is For

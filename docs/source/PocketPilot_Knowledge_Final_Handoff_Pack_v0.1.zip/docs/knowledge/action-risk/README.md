# Action-Risk Shelf

This shelf supports clearer readiness before action.

Its job is to help users understand PocketPilot’s action-support concepts without turning the product into a pressure surface or a rule-enforcement machine.

## Typical contents
- What Protection Plans Are For
- Stop Loss Basics
- Take Profit Basics
- Risk/Reward Basics
- Position Sizing Basics
- Why PocketPilot Supports Action Without Pushing Action

## Shelf rule
These docs should stay:
- practical
- calm
- structured
- support-first

They should explain readiness, risk framing, and discipline support without sounding like instructions barked through a megaphone.

## Best contextual homes
- Trade Hub
- bounded knowledge links from action-support surfaces
- library browsing for users preparing to act

---
topicId: pp-what-dashboard-is-for
title: "What Dashboard Is For"
difficulty: Beginner
mediaType: article
reviewStatus: normalized-draft-v1
family: orientation
priority: Now
surfaceFit:
  - Lib
  - Dash
---
# What Dashboard Is For

## Quick version
Dashboard is PocketPilot’s focus workspace. It goes deeper than Snapshot while staying structured, strategy-aware, and calm.

## Full version
If Snapshot answers, “What’s happening right now?” Dashboard answers, “How does this affect my strategy in more detail?”

Dashboard is the focus layer in the Scan → Focus → Deep model. It reshapes around the user’s chosen strategy while keeping the broader product structure stable. Different strategies change emphasis, not product identity.

The intended structure is hierarchical:
- Prime Zone
- Secondary Zone
- Deep Detail Layer

## What it is not
- not free-form user-built chaos
- not a random wall of indicators
- not a louder version of Snapshot

## Why it matters
Dashboard is where the product can explain signal relevance, market context, and strategy behavior without drowning the user in raw noise.

## Key terms
- Dashboard
- focus layer
- Prime Zone
- Secondary Zone

## Further reading
- What Snapshot Is For
- What Strategy Status Means
- What Knowledge Links Are For

---
topicId: pp-what-the-knowledge-library-is-for
title: "What the Knowledge Library Is For"
difficulty: Beginner
mediaType: article
reviewStatus: normalized-draft-v1
family: knowledge-system
priority: Now
surfaceFit:
  - Lib
  - Onboard
---
# What the Knowledge Library Is For

## Quick version
The Knowledge Library is PocketPilot’s optional learning and explanation layer. It helps users understand strategies, signals, MarketEvents, and product concepts without turning learning into a gate.

## Full version
The Knowledge Library exists both as:
- a persistent top-level tab
- a contextual support layer attached to strategies, signals, and events

Its job is to reduce beginner fear, support strategy selection, explain terms, and make the product easier to understand in the moment.

## What it is not
- not forced reading
- not a gate before execution
- not a generic crypto encyclopedia

## Why it matters
PocketPilot is an interpretation product. That means explanation has to be part of the system, not an afterthought.

## Key terms
- Knowledge Library
- contextual support layer
- optional learning
- knowledge empowers, never gatekeeps

## Further reading
- What Knowledge Links Are For
- Choosing Your Experience Level and Strategy
- What PocketPilot Is

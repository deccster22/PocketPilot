# PocketPilot Knowledge Library

The PocketPilot Knowledge Library is the product’s explanation and learning layer.

It exists to help users understand what PocketPilot is showing them, what different strategies mean, and how key concepts fit together without turning learning into a gate.

PocketPilot uses knowledge in two ways:
- as a **top-level library** users can browse intentionally
- as a **contextual support layer** attached to strategies, signals, events, and key product surfaces

The library is designed to stay:
- optional
- accessible
- non-intrusive
- strategy-first
- calm in tone
- useful in context

PocketPilot knowledge should help users feel smarter, calmer, and more in control. It should never feel like homework, compliance, or a velvet rope.

## Shelf structure

### Orientation
Front-door product understanding.

Use this shelf when the user needs to understand:
- what PocketPilot is
- how the main surfaces work
- how the product is different from a generic crypto app

### Interpretation
PocketPilot’s core language system.

Use this shelf when the user needs to understand:
- Strategy Alignment
- Strategy Fit
- Strategy Status
- MarketEvents
- estimated vs confirmed context
- state language like forming, developing, confirming, and resolved
- regime, alerts, and 30,000 ft View

### Strategies
The strategy academy.

This shelf contains:
- launch strategy guides
- future strategy additions
- strategy exploration support such as Strategy Preview / Strategy Navigator

### Action-Risk
Support for clearer readiness before action.

Use this shelf when the user needs help with:
- Protection Plans
- stop loss
- take profit
- risk/reward
- position sizing
- why PocketPilot supports action without pushing action

### Reflection
PocketPilot’s memory and learning layer.

Use this shelf when the user needs to understand:
- Since Last Checked
- Reorientation
- Insights
- Event Ledger
- Summary Archive
- monthly, quarterly, and annual review surfaces
- future log / journal concepts

### Knowledge System
How the knowledge layer behaves inside the product.

Use this shelf when the user needs to understand:
- what the Knowledge Library is for
- what Knowledge Links are for
- how learning support appears in context

## Publishing rules
- one canonical doc per topic by default
- calm, non-directive language
- no urgency, hype, or fake certainty
- strategy-first framing where relevant
- beginner-first readability without patronizing advanced users
- “how this appears in PocketPilot” sections where product translation matters
- future-facing topics must be labelled honestly as future-facing

## Contextual-link posture
- **Dashboard** is the strongest contextual-link surface
- **Trade Hub** supports bounded action/risk links
- **Snapshot** should stay minimal and is a caution zone
- **Insights** can support deeper reflective follow-ons

## Registers and templates
See:
- `_register/CONTENT_REGISTER.md`
- `_register/CONTENT_REGISTER.csv`
- `_templates/KNOWLEDGE_NODE_TEMPLATE.md`

# PocketPilot Core Concepts Pack v0.1

This pack is the repo-ready normalization sweep for the non-strategy concept shelf.

## What is included
- orientation docs
- interpretation docs
- action and risk docs
- reflection docs
- knowledge-system docs

## Publishing intent
These nodes are normalized into a consistent markdown shape with front matter and can be dropped into the broader Knowledge Library scaffold.

## Notes
- Strategy guides are intentionally not included here because they already live in the separate strategy pack.
- `what-log-and-journal-are-for.md` remains future-facing and should be treated more cautiously than the fully locked surface docs.

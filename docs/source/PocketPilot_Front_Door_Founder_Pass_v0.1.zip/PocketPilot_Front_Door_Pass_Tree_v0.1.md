# Front-Door Pass Tree v0.1

- `PocketPilot_Front_Door_Founder_Wording_Pass_v0.1.md`
- `PocketPilot_Knowledge_Repo_Drop_Overwrite_Guide_v0.1.md`
- `docs/knowledge/00-orientation/choosing-your-experience-level-and-strategy.md`
- `docs/knowledge/00-orientation/what-dashboard-is-for.md`
- `docs/knowledge/00-orientation/what-pocketpilot-is.md`
- `docs/knowledge/00-orientation/what-snapshot-is-for.md`
- `docs/knowledge/00-orientation/what-trade-hub-is-for.md`
- `docs/knowledge/50-knowledge-system/what-the-knowledge-library-is-for.md`
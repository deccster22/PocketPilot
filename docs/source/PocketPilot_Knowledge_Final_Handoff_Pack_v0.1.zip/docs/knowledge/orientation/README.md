# Orientation Shelf

This shelf contains the front-door knowledge layer for PocketPilot.

Its job is to answer:
- what is PocketPilot?
- how do the core surfaces work?
- why does the product feel different from a generic crypto app?

## Typical contents
- What PocketPilot Is
- Choosing Your Experience Level and Strategy
- What Snapshot Is For
- What Dashboard Is For
- What Trade Hub Is For
- Why PocketPilot Supports Action Without Pushing Action

## Shelf rule
Orientation docs should help users get their bearings fast.

They should feel:
- clear
- calm
- confidence-building
- easy to scan

They should not feel like a product manual dropped from orbit.

## Best contextual homes
- onboarding
- first-run support
- top-level library browsing
- occasional deep-link support from major surfaces

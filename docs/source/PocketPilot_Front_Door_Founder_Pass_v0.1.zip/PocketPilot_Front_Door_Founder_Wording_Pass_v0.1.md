# PocketPilot Front-Door Founder Wording Pass v0.1

## Purpose
This pass tightens the most visible user-facing docs so the first impression feels crisp, calm, and unmistakably PocketPilot.

It is not a content redesign. It is a wording pass on the docs most likely to shape first trust.

## Docs included
- `what-pocketpilot-is.md`
- `choosing-your-experience-level-and-strategy.md`
- `what-snapshot-is-for.md`
- `what-dashboard-is-for.md`
- `what-trade-hub-is-for.md`
- `what-the-knowledge-library-is-for.md`

## What changed
### Global changes
- strengthened first-sentence clarity
- reduced generic product-language drift
- removed a little internal-jargon stiffness where it hurt the first read
- kept the voice calm, capable, and non-directive
- preserved the same architecture and product posture

### Specific changes by doc
#### What PocketPilot Is
- sharper external positioning sentence
- clearer contrast with generic market apps and automation tools
- stronger “why this product exists” framing

#### Choosing Your Experience Level and Strategy
- clearer explanation of the difference between profile and strategy
- less setup-menu feeling
- stronger reassurance that the user is not being locked into a permanent identity test

#### What Snapshot Is For
- stronger emphasis on re-entry, zero-scroll calm, and why Snapshot must stay small
- tighter distinction from Dashboard

#### What Dashboard Is For
- stronger “focus workspace” framing
- cleaner explanation that strategy changes emphasis, not product identity

#### What Trade Hub Is For
- sharper action-support language
- reinforced support-not-push posture
- trimmed any wording that could feel accidentally execution-hypey

#### What the Knowledge Library Is For
- clearer top-level explanation of why the library exists
- stronger optional, non-gating framing
- more obvious connection between the library tab and contextual knowledge links

## Tone rules used in the pass
- say what the thing is before explaining what it is not
- keep the first paragraph human-readable without product-school homework vibes
- use plain contrast instead of inflated claims
- preserve PocketPilot’s calm tone even in action-adjacent surfaces
- make the product feel more capable, never more domineering

## Recommended review order
1. What PocketPilot Is
2. Choosing Your Experience Level and Strategy
3. What Snapshot Is For
4. What Dashboard Is For
5. What Trade Hub Is For
6. What the Knowledge Library Is For

## Recommendation
Apply these revised files after the unified drop lands, then do one final founder skim for phrase preference only.

If a line sparks “I’d say that differently,” change the line. If the structure feels right, leave the structure alone.

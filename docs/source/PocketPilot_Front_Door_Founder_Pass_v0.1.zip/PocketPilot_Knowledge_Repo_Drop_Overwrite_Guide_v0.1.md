# PocketPilot Knowledge Library Repo Drop and Overwrite Guide v0.1

## What this is
This guide explains the cleanest way to land the unified Knowledge Library drop into the repo without turning a good content pack into a merge-fight carnival.

It assumes you are importing the unified drop as a documentation-first change set, not trying to weave it into half-finished local edits by hand.

## Recommended import order
1. Create a short-lived branch for the docs drop.
2. Copy the unified drop into the repo root.
3. Review only `docs/knowledge/` and the root `README` additions from the pack.
4. Commit the scaffold and register first.
5. Commit the strategy and concept nodes second.
6. Apply the founder wording pass on the front-door docs as a final content polish layer.
7. Run verify checks if the repo treats docs paths as part of CI.
8. Open a PR with a narrow summary focused on documentation, IA, and content structure.

## Safe overwrite rules
### Safe to overwrite directly
These are generated content-structure files and should normally be replaced by the latest pack version:
- `docs/knowledge/_templates/KNOWLEDGE_NODE_TEMPLATE.md`
- `docs/knowledge/_register/CONTENT_REGISTER.md`
- `docs/knowledge/_register/CONTENT_REGISTER.csv`
- family `README.md` files under `docs/knowledge/`
- placeholder or generated node files that have not yet been manually edited in-repo

### Review before overwrite
These should be diffed before replacing if anyone has already started editing in the repo:
- `docs/knowledge/README.md`
- any orientation node
- any strategy node
- any existing knowledge doc that now has a more recent human edit than the generated pack

### Do not blindly overwrite
If these already exist and have live implementation meaning, review manually:
- links from product docs into knowledge nodes
- any docs referenced by app code, tests, or CMS import scripts
- any docs with hand-added founder notes not represented in the register

## Best practical workflow
### Option A: clean replace
Best when the repo does not yet contain a real `docs/knowledge/` tree.

```bash
unzip PocketPilot_Knowledge_Library_Unified_Drop_v0.1.zip -d /tmp/pp_knowledge_drop
rsync -av /tmp/pp_knowledge_drop/docs/knowledge/ ./docs/knowledge/
```

### Option B: diff-first merge
Best when the repo already contains draft knowledge files.

```bash
unzip PocketPilot_Knowledge_Library_Unified_Drop_v0.1.zip -d /tmp/pp_knowledge_drop
rsync -avun /tmp/pp_knowledge_drop/docs/knowledge/ ./docs/knowledge/
```

Use the dry-run first, inspect changed paths, then rerun without `-n` once happy.

### Option C: staged import
Best when you want the lowest-risk PR.

Import in three commits:
1. scaffold + templates + register
2. core concepts + strategy guides
3. founder wording pass on front-door docs

That makes review much easier and keeps arguments about wording separate from arguments about structure.

## Suggested commit sequence
### Commit 1
`docs(knowledge): add scaffold, register, and node template`

### Commit 2
`docs(knowledge): add normalized core concepts and launch strategy guides`

### Commit 3
`docs(knowledge): apply founder wording pass to front-door docs`

## Review checklist
- folder structure matches intended family split
- every node has front matter
- topic IDs are unique and stable
- no duplicate canonical nodes for the same concept
- strategy guides sit as first-class nodes, not one giant merged file
- Snapshot docs remain concise and do not become a study hall
- Trade Hub docs remain support-first and non-casino in tone
- future-facing docs are clearly marked as future-facing

## Front-door docs to review first
These are the highest-value first impression files:
- `docs/knowledge/00-orientation/what-pocketpilot-is.md`
- `docs/knowledge/00-orientation/choosing-your-experience-level-and-strategy.md`
- `docs/knowledge/00-orientation/what-snapshot-is-for.md`
- `docs/knowledge/00-orientation/what-dashboard-is-for.md`
- `docs/knowledge/00-orientation/what-trade-hub-is-for.md`
- `docs/knowledge/50-knowledge-system/what-the-knowledge-library-is-for.md`

## Why the founder wording pass lands last
The structure needs to settle before the voice gets sharpened. Otherwise you end up polishing copy in files that may still move.

The founder pass is not meant to rewrite the product philosophy. It is meant to make the first six doors sound deliberate, calm, and unmistakably PocketPilot.

## What success looks like
After import, the repo should have:
- one coherent `docs/knowledge/` tree
- one canonical content register
- normalized launch strategy guides
- normalized core concept docs
- polished front-door docs ready for founder review or light final edits

That gives you a usable publishing backbone instead of a folder full of well-meaning orphans.

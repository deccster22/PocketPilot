# Reflection Shelf

This shelf explains PocketPilot’s memory, review, and learning layer.

Its job is to help users understand how the product remembers useful context over time and how reflection can support learning without turning into shame, noise, or performance theatre.

## Typical contents
- What Since Last Checked Is For
- What Reorientation Is For
- What Insights Is For
- What Event Ledger Is For
- What Summary Archive Is For
- What Monthly and Quarterly Summaries Are For
- What Year in Review Is For
- What Log and Journal Are For

## Shelf rule
Reflection docs should feel:
- useful
- calm
- contextual
- respectful

They should not moralise behavior, gamify outcomes, or turn history into a guilt machine.

## Best contextual homes
- Insights
- summary and archive surfaces
- deeper reflective browsing

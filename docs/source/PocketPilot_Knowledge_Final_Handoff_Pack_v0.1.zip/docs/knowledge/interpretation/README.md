# Interpretation Shelf

This shelf teaches PocketPilot’s core language.

Its job is to help users understand how the product interprets markets through strategy rather than simply displaying raw signal clutter.

## Typical contents
- What Strategy Alignment Means
- What Strategy Fit Means
- What Strategy Status Means
- What a MarketEvent Is
- Estimated vs Confirmed Context
- Forming, Developing, Confirming, and Resolved
- What Market Regime Means
- Why PocketPilot Avoids Urgency Language
- What Alerts Are For
- What 30,000 ft View Is For

## Shelf rule
These docs should explain how PocketPilot talks and why.

They should feel:
- precise
- calm
- non-directive
- confidence-honest

They should not sound like the app is handing out prophecy or pressure.

## Best contextual homes
- Dashboard
- selected event or status detail
- selected signal explainer
- deeper library browsing

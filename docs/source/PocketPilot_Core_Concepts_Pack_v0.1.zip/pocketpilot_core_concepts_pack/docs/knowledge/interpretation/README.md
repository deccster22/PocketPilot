# Interpretation

Core PocketPilot language for state, events, fit, regime, alerts, and meaning.
